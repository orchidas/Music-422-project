# Music422Project
Final Project for Music 422 - Perceptual Audio Coding. 2018.
